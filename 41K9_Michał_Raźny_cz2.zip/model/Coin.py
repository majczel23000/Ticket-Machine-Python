class Coin:
    def __init__(self, value):
        self.value = value
