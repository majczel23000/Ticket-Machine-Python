from Controller import *
if __name__ == "__main__":
    c = Controller()