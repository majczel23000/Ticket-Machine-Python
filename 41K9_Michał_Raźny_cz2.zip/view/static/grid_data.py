from PyQt5 import QtCore

gridsData = {
    "zone1": {
        "n": {
            "name": "grid_normal_tickets_first"
        },
        "r": {
            "name": "grid_reduced_tickets_first"
        },
    },
    "zone2": {
        "n": {
            "name": "grid_normal_tickets_second"
        },
        "r": {
            "name": "grid_reduced_tickets_second"
        },
    }
}
